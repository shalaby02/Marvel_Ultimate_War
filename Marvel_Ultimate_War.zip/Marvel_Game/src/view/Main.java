package view;


public class Main {

	public static void main(String[] args) 
    { 
  
    	ProgressBar demo = new ProgressBar();
        
    } 
  
} 
